export interface TaskStats {
  total: number;
  completed: number;
  pending: number;
  teamMembers: number;
}

export interface GeneratedTask {
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  dueDate?: string;
}

export interface TeamActivity {
  id: number;
  user: {
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
  action: string;
  target: string;
  timestamp: string;
}
