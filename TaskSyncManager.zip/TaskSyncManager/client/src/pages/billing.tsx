import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { CreditCard, Download, Users, Calendar } from "lucide-react";

export default function Billing() {
  const { user } = useAuth();
  
  const { data: workspaces = [] } = useQuery({
    queryKey: ["/api/workspaces"],
  });

  const { data: members = [] } = useQuery({
    queryKey: ["/api/workspaces", workspaces[0]?.id, "members"],
    enabled: !!workspaces[0]?.id,
  });

  const currentWorkspace = workspaces[0];
  const hasActiveSubscription = user?.stripeSubscriptionId;
  const memberCount = members.length || 1;
  const monthlyTotal = memberCount * 5;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="pt-16">
        {/* Header */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Billing & Subscription</h1>
                <p className="mt-1 text-sm text-gray-600">
                  Manage your subscription and billing preferences
                </p>
              </div>
              {!hasActiveSubscription && (
                <Button className="bg-primary hover:bg-blue-700">
                  Upgrade to Pro
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Current Plan */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Current Plan</CardTitle>
                    <Badge variant={hasActiveSubscription ? "default" : "secondary"}>
                      {hasActiveSubscription ? "Pro Plan" : "Free Trial"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Plan Type</span>
                      <span className="font-medium">
                        {hasActiveSubscription ? "TaskSync Pro" : "Free Trial"}
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Active Users</span>
                      <span className="font-medium">{memberCount} users</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Price per User</span>
                      <span className="font-medium">$5.00/month</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Monthly Total</span>
                      <span className="font-bold text-lg">${monthlyTotal}.00</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Next Billing Date</span>
                      <span className="font-medium">
                        {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <div className="flex space-x-3">
                      <Button variant="outline">
                        <CreditCard className="h-4 w-4 mr-2" />
                        Update Payment Method
                      </Button>
                      <Button variant="outline">
                        Cancel Subscription
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Billing History */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Billing History</CardTitle>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {hasActiveSubscription ? (
                      <>
                        <div className="flex justify-between items-center p-4 border border-gray-200 rounded-lg">
                          <div>
                            <p className="font-medium">TaskSync Pro - November 2024</p>
                            <p className="text-sm text-gray-600">{memberCount} users × $5.00</p>
                            <p className="text-xs text-gray-500">Paid on November 15, 2024</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">${monthlyTotal}.00</p>
                            <Badge variant="outline" className="text-green-600 border-green-600">
                              Paid
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center p-4 border border-gray-200 rounded-lg">
                          <div>
                            <p className="font-medium">TaskSync Pro - October 2024</p>
                            <p className="text-sm text-gray-600">{memberCount} users × $5.00</p>
                            <p className="text-xs text-gray-500">Paid on October 15, 2024</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">${monthlyTotal}.00</p>
                            <Badge variant="outline" className="text-green-600 border-green-600">
                              Paid
                            </Badge>
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">No billing history yet</p>
                        <p className="text-sm text-gray-400 mt-2">
                          Your billing history will appear here after you upgrade to Pro
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Plan Features */}
              <Card>
                <CardHeader>
                  <CardTitle>Pro Plan Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">AI-powered task generation</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Unlimited workspaces</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">SMS notifications</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Meeting notes & AI summaries</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Advanced analytics</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Priority support</span>
                  </div>
                </CardContent>
              </Card>

              {/* Usage Stats */}
              <Card>
                <CardHeader>
                  <CardTitle>Usage This Month</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">Active Users</span>
                    </div>
                    <span className="font-medium">{memberCount}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">Tasks Created</span>
                    </div>
                    <span className="font-medium">47</span>
                  </div>
                </CardContent>
              </Card>

              {/* Support */}
              <Card>
                <CardHeader>
                  <CardTitle>Need Help?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Have questions about billing or need to make changes to your subscription?
                  </p>
                  <Button variant="outline" className="w-full">
                    Contact Support
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
