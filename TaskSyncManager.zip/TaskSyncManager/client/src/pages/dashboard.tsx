import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/navigation";
import { StatsOverview } from "@/components/stats-overview";
import { TaskItem } from "@/components/task-item";
import { AITaskCreator } from "@/components/ai-task-creator";
import { TeamActivity } from "@/components/team-activity";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Bot } from "lucide-react";
import { Task } from "@shared/schema";

export default function Dashboard() {
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: workspaces = [] } = useQuery({
    queryKey: ["/api/workspaces"],
  });

  const currentWorkspace = workspaces[0];

  const recentTasks = tasks.slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Header */}
      <div className="bg-white border-b border-gray-200 pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Good morning!</h1>
              <p className="mt-1 text-sm text-gray-600">Here's what's happening with your tasks today</p>
            </div>
            <div className="mt-4 sm:mt-0 flex space-x-3">
              <Button variant="outline" className="flex items-center">
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
              <Button className="bg-primary hover:bg-blue-700 flex items-center">
                <Bot className="h-4 w-4 mr-2" />
                AI Create
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <StatsOverview workspaceId={currentWorkspace?.id} />

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          {/* Recent Tasks */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Tasks</CardTitle>
                <Button variant="ghost" size="sm">View All</Button>
              </CardHeader>
              <CardContent>
                {recentTasks.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No tasks yet. Create your first task to get started!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentTasks.map((task) => (
                      <TaskItem key={task.id} task={task} />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <AITaskCreator workspaceId={currentWorkspace?.id} />
            <TeamActivity workspaceId={currentWorkspace?.id} />
            
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-between">
                  <span>Email Integration</span>
                  <span>→</span>
                </Button>
                <Button variant="outline" className="w-full justify-between">
                  <span>SMS Notifications</span>
                  <span>→</span>
                </Button>
                <Button variant="outline" className="w-full justify-between">
                  <span>Meeting Notes</span>
                  <span>→</span>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Analytics Preview */}
        <Card className="mt-8">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Productivity Analytics</CardTitle>
            <select className="text-sm border border-gray-300 rounded-lg px-3 py-1">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 3 months</option>
            </select>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-4">Task Completion Rate</h4>
                <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">87%</div>
                    <p className="text-sm text-gray-600">Average completion rate</p>
                    <div className="mt-4 w-32 h-2 bg-gray-200 rounded-full mx-auto">
                      <div className="w-28 h-2 bg-primary rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-4">Team Performance</h4>
                <div className="h-48 bg-gray-50 rounded-lg p-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Team Average</span>
                      <span className="text-sm font-medium text-gray-900">88%</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full">
                      <div className="w-4/5 h-2 bg-primary rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Banner */}
        <div className="gradient-bg text-white rounded-lg mt-8">
          <div className="p-6">
            <div className="flex flex-col sm:flex-row items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">Pro Plan - $5/user/month</h3>
                <p className="text-blue-100">Next billing: {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}</p>
              </div>
              <div className="mt-4 sm:mt-0 flex space-x-3">
                <Button variant="secondary">
                  Manage Billing
                </Button>
                <Button className="bg-blue-700 hover:bg-blue-800">
                  Add Users
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
