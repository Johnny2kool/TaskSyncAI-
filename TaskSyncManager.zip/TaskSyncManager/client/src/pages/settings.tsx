import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigation } from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings, 
  Mail, 
  Users, 
  Building, 
  Shield, 
  Bell, 
  Calendar,
  Database,
  Plus,
  CheckCircle,
  AlertCircle,
  Trash2
} from "lucide-react";

export default function SettingsPage() {
  const [isAddIntegrationOpen, setIsAddIntegrationOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: userSettings } = useQuery({
    queryKey: ["/api/settings"],
  });

  const { data: integrations = [] } = useQuery({
    queryKey: ["/api/integrations"],
  });

  const { data: privacySettings } = useQuery({
    queryKey: ["/api/privacy-settings"],
  });

  const { data: teamSettings } = useQuery({
    queryKey: ["/api/team-settings"],
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", "/api/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings Updated",
        description: "Your preferences have been saved successfully",
      });
    },
  });

  const addIntegrationMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/integrations", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/integrations"] });
      setIsAddIntegrationOpen(false);
      toast({
        title: "Integration Added",
        description: "Successfully connected to your account",
      });
    },
  });

  const updatePrivacyMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", "/api/privacy-settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/privacy-settings"] });
      toast({
        title: "Privacy Updated",
        description: "Your privacy preferences have been updated",
      });
    },
  });

  const handleAddIntegration = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const data = {
      type: formData.get("type") as string,
      name: formData.get("name") as string,
      settings: {
        apiKey: formData.get("apiKey") as string,
        instanceUrl: formData.get("instanceUrl") as string,
      },
    };

    addIntegrationMutation.mutate(data);
  };

  const integrationTypes = [
    { value: "teams", label: "Microsoft Teams", icon: Users },
    { value: "outlook", label: "Outlook Email", icon: Mail },
    { value: "gmail", label: "Gmail", icon: Mail },
    { value: "salesforce", label: "Salesforce CRM", icon: Building },
    { value: "hubspot", label: "HubSpot CRM", icon: Building },
    { value: "pipedrive", label: "Pipedrive CRM", icon: Building },
    { value: "zoho", label: "Zoho CRM", icon: Building },
    { value: "dynamics", label: "Microsoft Dynamics", icon: Building },
    { value: "zendesk", label: "Zendesk", icon: Building },
    { value: "slack", label: "Slack", icon: Users },
    { value: "google-calendar", label: "Google Calendar", icon: Calendar },
    { value: "outlook-calendar", label: "Outlook Calendar", icon: Calendar },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="pt-16">
        {/* Header */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center">
              <Settings className="h-8 w-8 text-primary mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
                <p className="mt-1 text-sm text-gray-600">
                  Manage integrations, privacy, and team settings
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Tabs defaultValue="integrations" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="integrations">Integrations</TabsTrigger>
              <TabsTrigger value="privacy">Privacy & Sharing</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="team">Team Management</TabsTrigger>
            </TabsList>

            {/* Integrations Tab */}
            <TabsContent value="integrations" className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">Connected Services</h2>
                  <p className="text-sm text-gray-600">Connect your external accounts and services</p>
                </div>
                <Dialog open={isAddIntegrationOpen} onOpenChange={setIsAddIntegrationOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-primary hover:bg-blue-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Integration
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Integration</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAddIntegration} className="space-y-4">
                      <div>
                        <Label>Service Type</Label>
                        <Select name="type" defaultValue="">
                          <SelectTrigger>
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                          <SelectContent>
                            {integrationTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Connection Name</Label>
                        <Input name="name" placeholder="My Sales Team Account" required />
                      </div>
                      <div>
                        <Label>API Key / Token</Label>
                        <Input name="apiKey" type="password" placeholder="Enter API key or token" />
                      </div>
                      <div>
                        <Label>Instance URL (if applicable)</Label>
                        <Input name="instanceUrl" placeholder="https://yourcompany.salesforce.com" />
                      </div>
                      <Button type="submit" disabled={addIntegrationMutation.isPending} className="w-full">
                        {addIntegrationMutation.isPending ? "Connecting..." : "Connect Service"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {integrations.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">No integrations connected yet</p>
                    <Button onClick={() => setIsAddIntegrationOpen(true)}>
                      Connect Your First Service
                    </Button>
                  </div>
                ) : (
                  integrations.map((integration: any) => (
                    <Card key={integration.id} className="relative">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                              <Building className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-medium text-gray-900">{integration.name}</h3>
                              <p className="text-sm text-gray-500">{integration.type}</p>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-green-600 border-green-600">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Active
                          </Badge>
                        </div>
                        <div className="space-y-2 text-sm text-gray-600">
                          <p>Connected: {new Date(integration.createdAt).toLocaleDateString()}</p>
                          <p>Last sync: {integration.lastSyncAt ? new Date(integration.lastSyncAt).toLocaleString() : 'Never'}</p>
                        </div>
                        <div className="mt-4 flex space-x-2">
                          <Button size="sm" variant="outline">Configure</Button>
                          <Button size="sm" variant="outline" className="text-red-600">
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Privacy Tab */}
            <TabsContent value="privacy" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Privacy & Data Sharing</h2>
                <p className="text-sm text-gray-600">Control what data is shared with your team</p>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Mail className="h-5 w-5 mr-2" />
                      Email Privacy
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Share Email Insights</Label>
                        <p className="text-sm text-gray-500">Allow AI to analyze emails for team insights</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.emailInsights ?? true} />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Private Email Mode</Label>
                        <p className="text-sm text-gray-500">Keep incoming emails private until you publish them</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.privateEmailMode ?? false} />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Auto-Create Tasks from Emails</Label>
                        <p className="text-sm text-gray-500">Automatically create tasks from email requests</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.autoCreateTasks ?? true} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Building className="h-5 w-5 mr-2" />
                      CRM Privacy
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Share Contact Updates</Label>
                        <p className="text-sm text-gray-500">Share CRM contact updates with team</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.shareContactUpdates ?? true} />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Private Deals</Label>
                        <p className="text-sm text-gray-500">Keep sales deals private until closed</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.privateDeals ?? false} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Users className="h-5 w-5 mr-2" />
                      Team Visibility
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Share Calendar</Label>
                        <p className="text-sm text-gray-500">Show your availability to team members</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.shareCalendar ?? true} />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-base">Share AI Insights</Label>
                        <p className="text-sm text-gray-500">Share AI-generated insights with team</p>
                      </div>
                      <Switch defaultChecked={privacySettings?.shareAiInsights ?? true} />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Notification Settings</h2>
                <p className="text-sm text-gray-600">Configure how and when you receive notifications</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bell className="h-5 w-5 mr-2" />
                      Push Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>New Tasks</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Email Alerts</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Meeting Reminders</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Team Updates</Label>
                      <Switch />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Mail className="h-5 w-5 mr-2" />
                      SMS Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Urgent Tasks</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>High Priority Emails</Label>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Meeting Conflicts</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>System Alerts</Label>
                      <Switch />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Team Management Tab */}
            <TabsContent value="team" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Team Management</h2>
                <p className="text-sm text-gray-600">Manage team permissions and data sharing</p>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Team Data Sharing Rules</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-base font-medium">Default Sharing Level</Label>
                      <Select defaultValue="team">
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="private">Private (Only Me)</SelectItem>
                          <SelectItem value="team">Team (My Workspace)</SelectItem>
                          <SelectItem value="public">Public (All Users)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Separator />

                    <div>
                      <Label className="text-base font-medium">Sales Team Privacy</Label>
                      <p className="text-sm text-gray-500 mb-3">
                        Configure privacy settings for sales-related data
                      </p>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>Keep prospect emails private</Label>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Auto-share closed deals</Label>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Share lead scoring insights</Label>
                          <Switch />
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div>
                      <Label className="text-base font-medium">AI Data Usage</Label>
                      <p className="text-sm text-gray-500 mb-3">
                        Control how AI uses your data for team insights
                      </p>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>Allow AI to analyze my emails</Label>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Share AI insights with team</Label>
                          <Switch defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Include my data in team reports</Label>
                          <Switch />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}