import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigation } from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Users, Plus, Mail, Phone, Building, Calendar, MessageCircle, Video, Coffee, FileText } from "lucide-react";

export default function CRM() {
  const [isAddContactOpen, setIsAddContactOpen] = useState(false);
  const [isAddInteractionOpen, setIsAddInteractionOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: contacts = [] } = useQuery({
    queryKey: ["/api/crm/contacts"],
  });

  const { data: interactions = [] } = useQuery({
    queryKey: ["/api/crm/interactions", selectedContact?.id],
    enabled: !!selectedContact?.id,
  });

  const createContactMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/crm/contacts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crm/contacts"] });
      setIsAddContactOpen(false);
      toast({
        title: "Success",
        description: "Contact created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create contact",
        variant: "destructive",
      });
    },
  });

  const addInteractionMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/crm/interactions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/crm/interactions", selectedContact?.id] 
      });
      setIsAddInteractionOpen(false);
      toast({
        title: "Success",
        description: "Interaction logged successfully",
      });
    },
  });

  const handleCreateContact = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const data = {
      email: formData.get("email") as string,
      firstName: formData.get("firstName") as string,
      lastName: formData.get("lastName") as string,
      company: formData.get("company") as string,
      title: formData.get("title") as string,
      phone: formData.get("phone") as string,
      notes: formData.get("notes") as string,
    };

    createContactMutation.mutate(data);
  };

  const handleAddInteraction = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const data = {
      contactId: selectedContact.id,
      type: formData.get("type") as string,
      subject: formData.get("subject") as string,
      content: formData.get("content") as string,
      outcome: formData.get("outcome") as string,
      duration: formData.get("duration") ? parseInt(formData.get("duration") as string) : null,
    };

    addInteractionMutation.mutate(data);
  };

  const getContactInitials = (contact: any) => {
    return `${contact.firstName?.[0] || ''}${contact.lastName?.[0] || ''}`.toUpperCase();
  };

  const getInteractionIcon = (type: string) => {
    switch (type) {
      case "email":
        return Mail;
      case "meeting":
        return Calendar;
      case "call":
        return Phone;
      default:
        return MessageCircle;
    }
  };

  const formatLastContact = (date: string) => {
    if (!date) return "Never";
    const now = new Date();
    const contactDate = new Date(date);
    const diffInDays = Math.floor((now.getTime() - contactDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return "Today";
    if (diffInDays === 1) return "Yesterday";
    if (diffInDays < 7) return `${diffInDays} days ago`;
    if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`;
    return `${Math.floor(diffInDays / 30)} months ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="pt-16">
        {/* Header */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">CRM & Contacts</h1>
                <p className="mt-1 text-sm text-gray-600">
                  Manage relationships and track interactions
                </p>
              </div>
              <Dialog open={isAddContactOpen} onOpenChange={setIsAddContactOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Contact
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Add New Contact</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateContact} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">First Name</label>
                        <Input name="firstName" required />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Last Name</label>
                        <Input name="lastName" required />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Email</label>
                      <Input name="email" type="email" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Company</label>
                        <Input name="company" />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Title</label>
                        <Input name="title" />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Phone</label>
                      <Input name="phone" type="tel" />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Notes</label>
                      <Textarea name="notes" rows={3} />
                    </div>
                    <Button type="submit" disabled={createContactMutation.isPending} className="w-full">
                      {createContactMutation.isPending ? "Creating..." : "Create Contact"}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Contacts</p>
                    <p className="text-2xl font-bold text-gray-900">{contacts.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Mail className="h-5 w-5 text-green-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Email Interactions</p>
                    <p className="text-2xl font-bold text-gray-900">147</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-blue-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Meetings</p>
                    <p className="text-2xl font-bold text-gray-900">23</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Building className="h-5 w-5 text-orange-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Companies</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {new Set(contacts.filter((c: any) => c.company).map((c: any) => c.company)).size}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contacts List */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>All Contacts</CardTitle>
                </CardHeader>
                <CardContent>
                  {contacts.length === 0 ? (
                    <div className="text-center py-12">
                      <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 mb-4">No contacts yet</p>
                      <Button onClick={() => setIsAddContactOpen(true)}>
                        Add Your First Contact
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {contacts.map((contact: any) => (
                        <div 
                          key={contact.id} 
                          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                            selectedContact?.id === contact.id 
                              ? "border-primary bg-primary/5" 
                              : "border-gray-200 hover:bg-gray-50"
                          }`}
                          onClick={() => setSelectedContact(contact)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <Avatar className="h-10 w-10">
                                <AvatarFallback>
                                  {getContactInitials(contact)}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <h3 className="font-medium text-gray-900">
                                  {contact.firstName} {contact.lastName}
                                </h3>
                                <p className="text-sm text-gray-600">{contact.email}</p>
                                {contact.company && (
                                  <p className="text-sm text-gray-500">
                                    {contact.title} at {contact.company}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-500">
                                Last contact: {formatLastContact(contact.lastContactAt)}
                              </p>
                              <div className="flex items-center space-x-2 mt-1">
                                {contact.phone && <Phone className="h-3 w-3 text-gray-400" />}
                                <Mail className="h-3 w-3 text-gray-400" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Contact Details & Interactions */}
            <div className="space-y-6">
              {selectedContact ? (
                <>
                  {/* Contact Details */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Contact Details</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 mb-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback>
                            {getContactInitials(selectedContact)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-medium text-gray-900">
                            {selectedContact.firstName} {selectedContact.lastName}
                          </h3>
                          <p className="text-sm text-gray-600">{selectedContact.email}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3 text-sm">
                        {selectedContact.company && (
                          <div className="flex items-center space-x-2">
                            <Building className="h-4 w-4 text-gray-400" />
                            <span>{selectedContact.title} at {selectedContact.company}</span>
                          </div>
                        )}
                        {selectedContact.phone && (
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-gray-400" />
                            <span>{selectedContact.phone}</span>
                          </div>
                        )}
                        <div className="flex items-center space-x-2">
                          <Mail className="h-4 w-4 text-gray-400" />
                          <span>{selectedContact.email}</span>
                        </div>
                      </div>

                      {selectedContact.notes && (
                        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-600">{selectedContact.notes}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Recent Interactions */}
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Recent Interactions</CardTitle>
                        <Dialog open={isAddInteractionOpen} onOpenChange={setIsAddInteractionOpen}>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline">
                              <Plus className="h-3 w-3 mr-1" />
                              Log
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle>Log New Interaction</DialogTitle>
                            </DialogHeader>
                            <form onSubmit={handleAddInteraction} className="space-y-4">
                              <div>
                                <Label>Interaction Type</Label>
                                <Select name="type" defaultValue="call">
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="call">Phone Call</SelectItem>
                                    <SelectItem value="meeting">In-Person Meeting</SelectItem>
                                    <SelectItem value="video">Video Call</SelectItem>
                                    <SelectItem value="coffee">Coffee Meeting</SelectItem>
                                    <SelectItem value="email">Email Exchange</SelectItem>
                                    <SelectItem value="demo">Product Demo</SelectItem>
                                    <SelectItem value="proposal">Proposal Presentation</SelectItem>
                                    <SelectItem value="follow_up">Follow-up</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label>Subject</Label>
                                <Input name="subject" placeholder="Discussion about project requirements" required />
                              </div>
                              <div>
                                <Label>Duration (minutes)</Label>
                                <Input name="duration" type="number" placeholder="30" />
                              </div>
                              <div>
                                <Label>Notes</Label>
                                <Textarea name="content" rows={3} placeholder="Key points discussed, next steps..." />
                              </div>
                              <div>
                                <Label>Outcome</Label>
                                <Select name="outcome" defaultValue="">
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select outcome" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="positive">Positive - Moving Forward</SelectItem>
                                    <SelectItem value="neutral">Neutral - More Info Needed</SelectItem>
                                    <SelectItem value="negative">Not Interested</SelectItem>
                                    <SelectItem value="scheduled">Follow-up Scheduled</SelectItem>
                                    <SelectItem value="closed">Deal Closed</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <Button type="submit" disabled={addInteractionMutation.isPending} className="w-full">
                                {addInteractionMutation.isPending ? "Logging..." : "Log Interaction"}
                              </Button>
                            </form>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {interactions.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">
                          No interactions recorded
                        </p>
                      ) : (
                        <div className="space-y-3">
                          {interactions.slice(0, 5).map((interaction: any) => {
                            const Icon = getInteractionIcon(interaction.type);
                            return (
                              <div key={interaction.id} className="flex items-start space-x-3">
                                <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                                  <Icon className="h-3 w-3 text-gray-600" />
                                </div>
                                <div className="flex-1">
                                  <p className="text-sm font-medium">{interaction.subject}</p>
                                  <p className="text-xs text-gray-500">
                                    {new Date(interaction.interactionAt).toLocaleDateString()}
                                  </p>
                                  {interaction.content && (
                                    <p className="text-xs text-gray-600 mt-1">
                                      {interaction.content}
                                    </p>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </>
              ) : (
                <Card>
                  <CardContent className="p-6 text-center">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">Select a contact to view details</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}