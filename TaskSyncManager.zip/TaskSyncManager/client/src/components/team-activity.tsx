import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users } from "lucide-react";

interface TeamActivityProps {
  workspaceId?: number;
}

export function TeamActivity({ workspaceId }: TeamActivityProps) {
  const { data: members = [] } = useQuery({
    queryKey: ["/api/workspaces", workspaceId, "members"],
    enabled: !!workspaceId,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ["/api/tasks"],
    enabled: !!workspaceId,
  });

  // Generate activity feed from recent task updates and member data
  const generateActivityFeed = () => {
    const activities = [];
    
    // Get recently completed tasks
    const recentCompletedTasks = tasks
      .filter((task: any) => task.status === "completed" && task.completedAt)
      .sort((a: any, b: any) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime())
      .slice(0, 2);

    // Get recently created tasks
    const recentCreatedTasks = tasks
      .filter((task: any) => task.status !== "completed")
      .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 1);

    // Add completed task activities
    recentCompletedTasks.forEach((task: any) => {
      const member = members.find((m: any) => m.userId === task.assigneeId);
      if (member) {
        activities.push({
          id: `completed-${task.id}`,
          type: "completed",
          user: member.user,
          action: "completed",
          target: task.title,
          timestamp: task.completedAt,
        });
      }
    });

    // Add created task activities
    recentCreatedTasks.forEach((task: any) => {
      const member = members.find((m: any) => m.userId === task.assigneeId);
      if (member) {
        activities.push({
          id: `created-${task.id}`,
          type: "created",
          user: member.user,
          action: "was assigned",
          target: task.title,
          timestamp: task.createdAt,
        });
      }
    });

    // Sort by timestamp
    return activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  };

  const activities = generateActivityFeed();

  const formatRelativeTime = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - time.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} minutes ago`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Users className="h-5 w-5 mr-2" />
          Team Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!workspaceId ? (
          <div className="text-center py-6">
            <Users className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-500">Select a workspace to see team activity</p>
          </div>
        ) : activities.length === 0 ? (
          <div className="text-center py-6">
            <Users className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-500">No recent team activity</p>
            <p className="text-xs text-gray-400 mt-1">Team activity will appear here as members complete tasks</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activities.map((activity) => (
              <div key={activity.id} className="flex items-center space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={activity.user.profileImageUrl} />
                  <AvatarFallback>
                    {activity.user.firstName?.[0]}{activity.user.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-900">
                    <span className="font-medium">
                      {activity.user.firstName} {activity.user.lastName}
                    </span>{" "}
                    {activity.action}{" "}
                    <span className="font-medium">"{activity.target}"</span>
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatRelativeTime(activity.timestamp)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
