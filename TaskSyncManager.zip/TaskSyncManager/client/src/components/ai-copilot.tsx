import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Bot, Send, Lightbulb, FileText, Users, Calendar, Loader2 } from "lucide-react";

interface AiMessage {
  id: number;
  role: "user" | "assistant";
  content: string;
  metadata?: any;
  createdAt: string;
}

export function AiCopilot() {
  const [question, setQuestion] = useState("");
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: conversations = [] } = useQuery({
    queryKey: ["/api/ai/conversations"],
  });

  const { data: messages = [] } = useQuery<AiMessage[]>({
    queryKey: ["/api/ai/conversations", currentConversationId, "messages"],
    enabled: !!currentConversationId,
  });

  const { data: insights } = useQuery({
    queryKey: ["/api/ai/insights"],
  });

  const askQuestionMutation = useMutation({
    mutationFn: async (question: string) => {
      const res = await apiRequest("POST", "/api/ai/ask", { 
        question, 
        conversationId: currentConversationId 
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/conversations"] });
      if (data.conversationId) {
        setCurrentConversationId(data.conversationId);
        queryClient.invalidateQueries({ 
          queryKey: ["/api/ai/conversations", data.conversationId, "messages"] 
        });
      }
      setQuestion("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to process your question",
        variant: "destructive",
      });
    },
  });

  const handleAskQuestion = () => {
    if (!question.trim()) return;
    askQuestionMutation.mutate(question);
  };

  const startNewConversation = () => {
    setCurrentConversationId(null);
    setQuestion("");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Conversation History */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center text-sm">
                    <Bot className="h-4 w-4 mr-2" />
                    AI Conversations
                  </CardTitle>
                  <Button size="sm" variant="outline" onClick={startNewConversation}>
                    New
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {conversations.length === 0 ? (
                      <p className="text-sm text-gray-500">No conversations yet</p>
                    ) : (
                      conversations.map((conv: any) => (
                        <div
                          key={conv.id}
                          className={`p-3 rounded-lg cursor-pointer transition-colors ${
                            currentConversationId === conv.id
                              ? "bg-primary/10 border-primary"
                              : "bg-gray-50 hover:bg-gray-100"
                          }`}
                          onClick={() => setCurrentConversationId(conv.id)}
                        >
                          <p className="font-medium text-sm truncate">
                            {conv.title || "AI Conversation"}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(conv.updatedAt).toLocaleDateString()}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Main Chat Interface */}
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="h-5 w-5 mr-2 text-primary" />
                  AI Copilot
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col h-96">
                {/* Messages */}
                <ScrollArea className="flex-1 mb-4">
                  <div className="space-y-4">
                    {messages.length === 0 ? (
                      <div className="text-center py-12">
                        <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                          Welcome to AI Copilot
                        </h3>
                        <p className="text-gray-500 mb-6">
                          Ask me anything about your work, tasks, emails, or team data
                        </p>
                        <div className="grid grid-cols-1 gap-2 max-w-sm mx-auto">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setQuestion("What tasks are overdue?")}
                          >
                            What tasks are overdue?
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setQuestion("Show me my recent email conversations")}
                          >
                            Show recent emails
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setQuestion("What meetings do I have this week?")}
                          >
                            Upcoming meetings?
                          </Button>
                        </div>
                      </div>
                    ) : (
                      messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${
                            message.role === "user" ? "justify-end" : "justify-start"
                          }`}
                        >
                          <div
                            className={`max-w-3xl p-4 rounded-lg ${
                              message.role === "user"
                                ? "bg-primary text-white"
                                : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            {message.role === "assistant" && (
                              <div className="flex items-center mb-2">
                                <Bot className="h-4 w-4 mr-2" />
                                <span className="font-medium text-sm">AI Copilot</span>
                              </div>
                            )}
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                            {message.metadata?.relatedData && (
                              <div className="mt-3 pt-3 border-t border-gray-200">
                                <p className="text-xs font-medium mb-2">Related:</p>
                                <div className="flex flex-wrap gap-1">
                                  {message.metadata.relatedData.tasks && (
                                    <Badge variant="outline" className="text-xs">
                                      {message.metadata.relatedData.tasks.length} tasks
                                    </Badge>
                                  )}
                                  {message.metadata.relatedData.emails && (
                                    <Badge variant="outline" className="text-xs">
                                      {message.metadata.relatedData.emails.length} emails
                                    </Badge>
                                  )}
                                  {message.metadata.relatedData.contacts && (
                                    <Badge variant="outline" className="text-xs">
                                      {message.metadata.relatedData.contacts.length} contacts
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>

                {/* Input */}
                <div className="flex space-x-2">
                  <Input
                    placeholder="Ask me anything about your work..."
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleAskQuestion()}
                    disabled={askQuestionMutation.isPending}
                  />
                  <Button
                    onClick={handleAskQuestion}
                    disabled={!question.trim() || askQuestionMutation.isPending}
                    className="bg-primary hover:bg-blue-700"
                  >
                    {askQuestionMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Insights & Quick Actions */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              {/* Work Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-sm">
                    <Lightbulb className="h-4 w-4 mr-2" />
                    AI Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {insights?.insights ? (
                    <div className="space-y-3">
                      {insights.insights.slice(0, 3).map((insight: any, index: number) => (
                        <div key={index} className="p-3 bg-blue-50 rounded-lg">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-medium text-blue-800">
                              {insight.type}
                            </span>
                            <Badge
                              variant="outline"
                              className={
                                insight.priority === "high"
                                  ? "border-red-300 text-red-700"
                                  : insight.priority === "medium"
                                  ? "border-orange-300 text-orange-700"
                                  : "border-gray-300 text-gray-700"
                              }
                            >
                              {insight.priority}
                            </Badge>
                          </div>
                          <h4 className="font-medium text-sm text-gray-900 mb-1">
                            {insight.title}
                          </h4>
                          <p className="text-xs text-gray-600">{insight.description}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">
                      AI insights will appear here as you use TaskSync
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setQuestion("Summarize my week")}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Weekly Summary
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setQuestion("Who should I follow up with?")}
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Follow-up Suggestions
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setQuestion("What meetings need prep?")}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Meeting Prep
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}