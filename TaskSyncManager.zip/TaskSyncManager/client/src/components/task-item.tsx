import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Task } from "@shared/schema";
import { Clock, Calendar } from "lucide-react";

interface TaskItemProps {
  task: Task;
  showWorkspace?: boolean;
}

export function TaskItem({ task, showWorkspace = false }: TaskItemProps) {
  const [isCompleted, setIsCompleted] = useState(task.status === "completed");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const res = await apiRequest("PATCH", `/api/tasks/${task.id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
      toast({
        title: "Success",
        description: `Task ${isCompleted ? "unmarked" : "completed"}!`,
      });
    },
    onError: (error: any) => {
      setIsCompleted(!isCompleted); // Revert optimistic update
      toast({
        title: "Error",
        description: error.message || "Failed to update task",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (checked: boolean) => {
    setIsCompleted(checked);
    const newStatus = checked ? "completed" : "pending";
    updateStatusMutation.mutate(newStatus);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-orange-100 text-orange-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (date: string | null) => {
    if (!date) return null;
    const d = new Date(date);
    const now = new Date();
    const diff = d.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return "Today";
    if (days === 1) return "Tomorrow";
    if (days === -1) return "Yesterday";
    if (days < 0) return `${Math.abs(days)} days ago`;
    return `In ${days} days`;
  };

  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
      <div className="flex items-center space-x-3 flex-1">
        <Checkbox 
          checked={isCompleted}
          onCheckedChange={handleStatusChange}
          disabled={updateStatusMutation.isPending}
        />
        <div className="flex-1">
          <h3 className={`font-medium ${isCompleted ? "line-through text-gray-500" : "text-gray-900"}`}>
            {task.title}
          </h3>
          {task.description && (
            <p className="text-sm text-gray-600 mt-1">{task.description}</p>
          )}
          <div className="flex items-center space-x-4 mt-2">
            <Badge variant="outline" className={getPriorityColor(task.priority)}>
              {task.priority} priority
            </Badge>
            {task.status !== "completed" && (
              <Badge variant="outline" className={getStatusColor(task.status)}>
                {task.status.replace("_", " ")}
              </Badge>
            )}
            {task.dueDate && (
              <div className="flex items-center text-xs text-gray-500">
                <Calendar className="h-3 w-3 mr-1" />
                Due: {formatDate(task.dueDate)}
              </div>
            )}
            {task.completedAt && (
              <div className="flex items-center text-xs text-gray-500">
                <Clock className="h-3 w-3 mr-1" />
                Completed: {formatDate(task.completedAt)}
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 ml-4">
        {task.assigneeId && (
          <Avatar className="h-6 w-6">
            <AvatarFallback className="text-xs">
              {task.assigneeId.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        )}
      </div>
    </div>
  );
}
