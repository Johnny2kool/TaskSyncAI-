import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Bot, Plus, Loader2 } from "lucide-react";
import { GeneratedTask } from "@/lib/types";

interface AITaskCreatorProps {
  workspaceId?: number;
}

export function AITaskCreator({ workspaceId }: AITaskCreatorProps) {
  const [text, setText] = useState("");
  const [generatedTasks, setGeneratedTasks] = useState<GeneratedTask[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateTasksMutation = useMutation({
    mutationFn: async (text: string) => {
      if (!workspaceId) {
        throw new Error("No workspace selected");
      }
      const res = await apiRequest("POST", "/api/ai/generate-tasks", { text, workspaceId });
      return res.json();
    },
    onSuccess: (data) => {
      setGeneratedTasks(data.tasks || []);
      if (data.tasks?.length === 0) {
        toast({
          title: "No tasks generated",
          description: "Try providing more specific text with actionable items.",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate tasks",
        variant: "destructive",
      });
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (task: GeneratedTask) => {
      const res = await apiRequest("POST", "/api/tasks", {
        title: task.title,
        description: task.description,
        priority: task.priority,
        workspaceId,
        dueDate: task.dueDate ? new Date(task.dueDate) : null,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Success",
        description: "Task created successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create task",
        variant: "destructive",
      });
    },
  });

  const handleGenerateTasks = () => {
    if (!text.trim()) {
      toast({
        title: "Error",
        description: "Please enter some text to generate tasks from",
        variant: "destructive",
      });
      return;
    }
    generateTasksMutation.mutate(text);
  };

  const handleCreateTask = (task: GeneratedTask) => {
    createTaskMutation.mutate(task);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-orange-100 text-orange-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bot className="h-5 w-5 mr-2 text-primary" />
          AI Task Creator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="Describe your tasks or paste email content here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="h-24 resize-none"
        />
        
        <Button 
          onClick={handleGenerateTasks}
          disabled={generateTasksMutation.isPending || !workspaceId}
          className="w-full bg-primary hover:bg-blue-700"
        >
          {generateTasksMutation.isPending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Bot className="h-4 w-4 mr-2" />
              Generate Tasks
            </>
          )}
        </Button>

        {!workspaceId && (
          <p className="text-xs text-gray-500">
            Create a workspace first to use AI task generation
          </p>
        )}

        {generatedTasks.length > 0 && (
          <div className="space-y-3 pt-4 border-t">
            <h4 className="font-medium text-sm">Generated Tasks:</h4>
            {generatedTasks.map((task, index) => (
              <div key={index} className="p-3 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <h5 className="font-medium text-sm">{task.title}</h5>
                  <Badge variant="outline" className={getPriorityColor(task.priority)}>
                    {task.priority}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600 mb-3">{task.description}</p>
                {task.dueDate && (
                  <p className="text-xs text-gray-500 mb-3">
                    Due: {new Date(task.dueDate).toLocaleDateString()}
                  </p>
                )}
                <Button
                  size="sm"
                  onClick={() => handleCreateTask(task)}
                  disabled={createTaskMutation.isPending}
                  className="w-full"
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Create Task
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
