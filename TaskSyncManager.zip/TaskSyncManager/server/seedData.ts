import { storage } from "./storage";

export async function seedTestData(userId: string) {
  try {
    // Create sample CRM contacts
    const contacts = [
      {
        userId,
        email: "sarah.johnson@techcorp.com",
        firstName: "Sarah",
        lastName: "Johnson", 
        company: "TechCorp Solutions",
        title: "VP of Engineering",
        phone: "+1 (555) 123-4567",
        notes: "Interested in enterprise productivity solutions. Budget approved for Q1.",
        lastContactAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      },
      {
        userId,
        email: "mike.chen@innovate.io",
        firstName: "Mike",
        lastName: "Chen",
        company: "Innovate.io",
        title: "CTO",
        phone: "+1 (555) 987-6543",
        notes: "Looking for AI-powered team collaboration tools. Fast-growing startup.",
        lastContactAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      },
      {
        userId,
        email: "jessica.torres@globalcorp.com",
        firstName: "Jessica",
        lastName: "Torres",
        company: "GlobalCorp",
        title: "Director of Operations",
        phone: "+1 (555) 456-7890",
        notes: "Managing 200+ team members. Needs better email integration and task automation.",
        lastContactAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        userId,
        email: "david.park@startup.co",
        firstName: "David",
        lastName: "Park",
        company: "Startup.co",
        title: "Founder & CEO",
        phone: "+1 (555) 321-0987",
        notes: "Early-stage startup, price-sensitive but very interested in AI features.",
        lastContactAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 1 week ago
      }
    ];

    const createdContacts = [];
    for (const contact of contacts) {
      const newContact = await storage.createCrmContact(contact);
      createdContacts.push(newContact);
    }

    // Create sample interactions for each contact
    const interactions = [
      // Sarah Johnson interactions
      {
        contactId: createdContacts[0].id,
        type: "video",
        subject: "Product Demo - TaskSync AI+ Overview",
        content: "Demonstrated AI Copilot, email monitoring, and CRM integration. Sarah was impressed with the privacy controls and team management features. She asked about enterprise pricing and security compliance.",
        outcome: "positive",
        duration: 45,
        interactionAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        contactId: createdContacts[0].id,
        type: "email",
        subject: "Follow-up: Security Documentation",
        content: "Sent SOC 2 compliance docs and enterprise security overview. Sarah confirmed budget approval and wants to schedule team trial.",
        outcome: "scheduled",
        interactionAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
      
      // Mike Chen interactions
      {
        contactId: createdContacts[1].id,
        type: "call",
        subject: "Initial Discovery Call",
        content: "Discussed current pain points with team communication. Mike's team uses Slack but needs better email integration and AI-powered insights. Startup budget constraints but growth funding expected.",
        outcome: "neutral",
        duration: 30,
        interactionAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      },
      {
        contactId: createdContacts[1].id,
        type: "demo",
        subject: "AI Copilot Demo for Engineering Team",
        content: "Showed AI copilot querying code repos, team data, and automated task creation. Mike loved the integration possibilities with their dev tools.",
        outcome: "positive",
        duration: 60,
        interactionAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      },

      // Jessica Torres interactions
      {
        contactId: createdContacts[2].id,
        type: "meeting",
        subject: "In-Person Meeting at GlobalCorp HQ",
        content: "Met with Jessica and her operations team. Discussed scaling challenges with 200+ team members. They need better email automation and task delegation features. Very interested in privacy controls for sensitive projects.",
        outcome: "positive",
        duration: 90,
        interactionAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      },
      {
        contactId: createdContacts[2].id,
        type: "proposal",
        subject: "Enterprise Plan Proposal Presentation",
        content: "Presented custom enterprise solution with advanced privacy controls, dedicated support, and custom integrations. Jessica requested pricing for 200 users and implementation timeline.",
        outcome: "scheduled",
        duration: 75,
        interactionAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
      },

      // David Park interactions
      {
        contactId: createdContacts[3].id,
        type: "coffee",
        subject: "Casual Coffee Meeting - Startup Founder Chat",
        content: "Informal discussion about startup challenges and productivity tools. David is bootstrapping but sees huge value in AI-powered automation. Interested in startup discount program.",
        outcome: "neutral",
        duration: 45,
        interactionAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      },
      {
        contactId: createdContacts[3].id,
        type: "follow_up",
        subject: "Startup Pricing Discussion",
        content: "Discussed special startup pricing tier. David appreciated the offer but needs to wait for next funding round. Asked to stay in touch for Q2.",
        outcome: "scheduled",
        interactionAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      }
    ];

    for (const interaction of interactions) {
      await storage.createCrmInteraction(interaction);
    }

    // Create sample tasks
    const tasks = [
      {
        workspaceId: 1,
        title: "Prepare enterprise security documentation for TechCorp",
        description: "Compile SOC 2 compliance docs, security overview, and privacy policy for Sarah Johnson's team review",
        status: "in_progress",
        priority: "high",
        assigneeId: userId,
        dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      },
      {
        workspaceId: 1,
        title: "Follow up with Mike Chen on pricing",
        description: "Send startup discount information and schedule technical integration call",
        status: "pending",
        priority: "medium",
        assigneeId: userId,
        dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // tomorrow
      },
      {
        workspaceId: 1,
        title: "Create custom demo for GlobalCorp operations team",
        description: "Prepare specialized demo focusing on email automation and task delegation for 200+ user organization",
        status: "pending",
        priority: "high",
        assigneeId: userId,
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      },
      {
        workspaceId: 1,
        title: "Research startup funding trends for Q2 outreach",
        description: "Identify newly funded startups that might need productivity solutions",
        status: "pending",
        priority: "low",
        assigneeId: userId,
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1 week from now
      }
    ];

    for (const task of tasks) {
      await storage.createTask(task);
    }

    // Create sample AI conversation
    const conversation = await storage.createAiConversation({
      userId,
      title: "Sales pipeline analysis and next steps",
    });

    const aiMessages = [
      {
        conversationId: conversation.id,
        role: "user",
        content: "What's the status of my current sales pipeline and what should I prioritize this week?",
      },
      {
        conversationId: conversation.id,
        role: "assistant",
        content: "Based on your CRM data, you have 4 active prospects with varying levels of engagement:\n\n**High Priority:**\n• Jessica Torres (GlobalCorp) - Just had positive proposal meeting, waiting on pricing decision\n• Sarah Johnson (TechCorp) - Demo completed, security docs sent, budget approved\n\n**Medium Priority:**\n• Mike Chen (Innovate.io) - Positive demo response, waiting on startup pricing\n\n**Low Priority:**\n• David Park (Startup.co) - Interested but waiting for funding\n\n**Recommended Actions This Week:**\n1. Follow up with Jessica on enterprise pricing\n2. Schedule implementation call with Sarah\n3. Send startup discount info to Mike\n4. Check in with David in Q2",
        metadata: {
          relatedData: {
            contacts: createdContacts.slice(0, 4),
            tasks: tasks.slice(0, 3)
          }
        }
      }
    ];

    for (const message of aiMessages) {
      await storage.createAiMessage(message);
    }

    console.log("✅ Sample data created successfully!");
    return { contacts: createdContacts, interactions, tasks, conversation };

  } catch (error) {
    console.error("Error creating sample data:", error);
    throw error;
  }
}