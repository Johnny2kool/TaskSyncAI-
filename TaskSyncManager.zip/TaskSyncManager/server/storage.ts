import {
  users,
  workspaces,
  tasks,
  workspaceMembers,
  meetingNotes,
  notifications,
  emailAccounts,
  emailConversations,
  emailMessages,
  crmContacts,
  crmInteractions,
  aiConversations,
  aiMessages,
  type User,
  type UpsertUser,
  type Workspace,
  type InsertWorkspace,
  type Task,
  type InsertTask,
  type WorkspaceMember,
  type InsertWorkspaceMember,
  type MeetingNote,
  type InsertMeetingNote,
  type Notification,
  type InsertNotification,
  type EmailAccount,
  type InsertEmailAccount,
  type EmailConversation,
  type EmailMessage,
  type CrmContact,
  type InsertCrmContact,
  type CrmInteraction,
  type InsertCrmInteraction,
  type AiConversation,
  type InsertAiConversation,
  type AiMessage,
  type InsertAiMessage,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User>;
  
  // Workspace operations
  createWorkspace(workspace: InsertWorkspace): Promise<Workspace>;
  getUserWorkspaces(userId: string): Promise<Workspace[]>;
  getWorkspace(id: number): Promise<Workspace | undefined>;
  addWorkspaceMember(member: InsertWorkspaceMember): Promise<WorkspaceMember>;
  getWorkspaceMembers(workspaceId: number): Promise<(WorkspaceMember & { user: User })[]>;
  
  // Task operations
  createTask(task: InsertTask): Promise<Task>;
  getUserTasks(userId: string, workspaceId?: number): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  updateTaskStatus(id: number, status: string): Promise<Task>;
  getTaskStats(workspaceId: number): Promise<{ total: number; completed: number; pending: number; }>;
  
  // Meeting notes operations
  createMeetingNote(note: InsertMeetingNote): Promise<MeetingNote>;
  getMeetingNotes(workspaceId: number): Promise<MeetingNote[]>;
  
  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string): Promise<Notification[]>;
  markNotificationRead(id: number): Promise<void>;
  
  // Email operations
  createEmailAccount(account: InsertEmailAccount): Promise<EmailAccount>;
  getUserEmailAccounts(userId: string): Promise<EmailAccount[]>;
  createEmailMessage(message: any): Promise<EmailMessage>;
  getEmailConversations(userId: string): Promise<EmailConversation[]>;
  
  // CRM operations
  createCrmContact(contact: InsertCrmContact): Promise<CrmContact>;
  getUserCrmContacts(userId: string): Promise<CrmContact[]>;
  updateCrmContact(id: number, updates: Partial<CrmContact>): Promise<CrmContact>;
  createCrmInteraction(interaction: InsertCrmInteraction): Promise<CrmInteraction>;
  getContactInteractions(contactId: number): Promise<CrmInteraction[]>;
  
  // AI Copilot operations
  createAiConversation(conversation: InsertAiConversation): Promise<AiConversation>;
  getUserAiConversations(userId: string): Promise<AiConversation[]>;
  createAiMessage(message: InsertAiMessage): Promise<AiMessage>;
  getAiConversationMessages(conversationId: number): Promise<AiMessage[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId,
        stripeSubscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Workspace operations
  async createWorkspace(workspace: InsertWorkspace): Promise<Workspace> {
    const [newWorkspace] = await db.insert(workspaces).values(workspace).returning();
    
    // Add owner as admin member
    await db.insert(workspaceMembers).values({
      workspaceId: newWorkspace.id,
      userId: workspace.ownerId,
      role: "owner",
    });
    
    return newWorkspace;
  }

  async getUserWorkspaces(userId: string): Promise<Workspace[]> {
    const userWorkspaces = await db
      .select({ workspace: workspaces })
      .from(workspaces)
      .innerJoin(workspaceMembers, eq(workspaces.id, workspaceMembers.workspaceId))
      .where(eq(workspaceMembers.userId, userId));
    
    return userWorkspaces.map(({ workspace }) => workspace);
  }

  async getWorkspace(id: number): Promise<Workspace | undefined> {
    const [workspace] = await db.select().from(workspaces).where(eq(workspaces.id, id));
    return workspace;
  }

  async addWorkspaceMember(member: InsertWorkspaceMember): Promise<WorkspaceMember> {
    const [newMember] = await db.insert(workspaceMembers).values(member).returning();
    return newMember;
  }

  async getWorkspaceMembers(workspaceId: number): Promise<(WorkspaceMember & { user: User })[]> {
    const members = await db
      .select()
      .from(workspaceMembers)
      .innerJoin(users, eq(workspaceMembers.userId, users.id))
      .where(eq(workspaceMembers.workspaceId, workspaceId));
    
    return members.map(({ workspace_members, users: user }) => ({
      ...workspace_members,
      user,
    }));
  }

  // Task operations
  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async getUserTasks(userId: string, workspaceId?: number): Promise<Task[]> {
    if (workspaceId) {
      return await db
        .select()
        .from(tasks)
        .where(and(eq(tasks.assigneeId, userId), eq(tasks.workspaceId, workspaceId)))
        .orderBy(desc(tasks.createdAt));
    }
    
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.assigneeId, userId))
      .orderBy(desc(tasks.createdAt));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async updateTaskStatus(id: number, status: string): Promise<Task> {
    const updates: any = { status, updatedAt: new Date() };
    if (status === "completed") {
      updates.completedAt = new Date();
    }
    
    const [task] = await db
      .update(tasks)
      .set(updates)
      .where(eq(tasks.id, id))
      .returning();
    return task;
  }

  async getTaskStats(workspaceId: number): Promise<{ total: number; completed: number; pending: number; }> {
    const allTasks = await db.select().from(tasks).where(eq(tasks.workspaceId, workspaceId));
    
    const total = allTasks.length;
    const completed = allTasks.filter(task => task.status === "completed").length;
    const pending = allTasks.filter(task => task.status === "pending").length;
    
    return { total, completed, pending };
  }

  // Meeting notes operations
  async createMeetingNote(note: InsertMeetingNote): Promise<MeetingNote> {
    const [newNote] = await db.insert(meetingNotes).values(note).returning();
    return newNote;
  }

  async getMeetingNotes(workspaceId: number): Promise<MeetingNote[]> {
    return await db
      .select()
      .from(meetingNotes)
      .where(eq(meetingNotes.workspaceId, workspaceId))
      .orderBy(desc(meetingNotes.createdAt));
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async getUserNotifications(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async markNotificationRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }

  // Email operations
  async createEmailAccount(account: InsertEmailAccount): Promise<EmailAccount> {
    const [newAccount] = await db.insert(emailAccounts).values(account).returning();
    return newAccount;
  }

  async getUserEmailAccounts(userId: string): Promise<EmailAccount[]> {
    return await db
      .select()
      .from(emailAccounts)
      .where(eq(emailAccounts.userId, userId));
  }

  async createEmailMessage(message: any): Promise<EmailMessage> {
    const [newMessage] = await db.insert(emailMessages).values(message).returning();
    return newMessage;
  }

  async getEmailConversations(userId: string): Promise<EmailConversation[]> {
    const userAccounts = await this.getUserEmailAccounts(userId);
    const accountIds = userAccounts.map(acc => acc.id);
    
    if (accountIds.length === 0) return [];
    
    return await db
      .select()
      .from(emailConversations)
      .where(eq(emailConversations.accountId, accountIds[0]))
      .orderBy(desc(emailConversations.lastMessageAt));
  }

  // CRM operations
  async createCrmContact(contact: InsertCrmContact): Promise<CrmContact> {
    const [newContact] = await db.insert(crmContacts).values(contact).returning();
    return newContact;
  }

  async getUserCrmContacts(userId: string): Promise<CrmContact[]> {
    return await db
      .select()
      .from(crmContacts)
      .where(eq(crmContacts.userId, userId))
      .orderBy(desc(crmContacts.lastContactAt));
  }

  async updateCrmContact(id: number, updates: Partial<CrmContact>): Promise<CrmContact> {
    const [contact] = await db
      .update(crmContacts)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(crmContacts.id, id))
      .returning();
    return contact;
  }

  async createCrmInteraction(interaction: InsertCrmInteraction): Promise<CrmInteraction> {
    const [newInteraction] = await db.insert(crmInteractions).values(interaction).returning();
    return newInteraction;
  }

  async getContactInteractions(contactId: number): Promise<CrmInteraction[]> {
    return await db
      .select()
      .from(crmInteractions)
      .where(eq(crmInteractions.contactId, contactId))
      .orderBy(desc(crmInteractions.interactionAt));
  }

  // AI Copilot operations
  async createAiConversation(conversation: InsertAiConversation): Promise<AiConversation> {
    const [newConversation] = await db.insert(aiConversations).values(conversation).returning();
    return newConversation;
  }

  async getUserAiConversations(userId: string): Promise<AiConversation[]> {
    return await db
      .select()
      .from(aiConversations)
      .where(eq(aiConversations.userId, userId))
      .orderBy(desc(aiConversations.updatedAt));
  }

  async createAiMessage(message: InsertAiMessage): Promise<AiMessage> {
    const [newMessage] = await db.insert(aiMessages).values(message).returning();
    return newMessage;
  }

  async getAiConversationMessages(conversationId: number): Promise<AiMessage[]> {
    return await db
      .select()
      .from(aiMessages)
      .where(eq(aiMessages.conversationId, conversationId))
      .orderBy(desc(aiMessages.createdAt));
  }
}

export const storage = new DatabaseStorage();
