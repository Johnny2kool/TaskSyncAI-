import twilio from "twilio";

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromNumber = process.env.TWILIO_PHONE_NUMBER;

const client = twilio(accountSid, authToken);

export interface SMSNotification {
  to: string;
  message: string;
}

export async function sendSMS({ to, message }: SMSNotification): Promise<boolean> {
  if (!accountSid || !authToken || !fromNumber) {
    console.warn("Twilio credentials not configured, SMS notification skipped");
    return false;
  }

  try {
    await client.messages.create({
      body: message,
      from: fromNumber,
      to: to,
    });
    
    console.log(`SMS sent successfully to ${to}`);
    return true;
  } catch (error) {
    console.error("Error sending SMS:", error);
    return false;
  }
}

export async function sendTaskReminder(to: string, taskTitle: string, dueDate: string): Promise<boolean> {
  const message = `📋 TaskSync Reminder: "${taskTitle}" is due ${dueDate}. Complete it now to stay on track!`;
  return await sendSMS({ to, message });
}

export async function sendTaskAssignment(to: string, taskTitle: string, assignedBy: string): Promise<boolean> {
  const message = `🎯 New task assigned: "${taskTitle}" by ${assignedBy}. Check TaskSync for details.`;
  return await sendSMS({ to, message });
}

export async function sendTaskCompletion(to: string, taskTitle: string, completedBy: string): Promise<boolean> {
  const message = `✅ Task completed: "${taskTitle}" by ${completedBy}. Great teamwork!`;
  return await sendSMS({ to, message });
}
