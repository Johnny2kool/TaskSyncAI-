import OpenAI from "openai";
import { storage } from "../storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_SECRET_KEY || process.env.OPENAI_TOKEN
});

export interface CopilotContext {
  userId: string;
  workspaceId?: number;
  recentTasks: any[];
  recentEmails: any[];
  recentMeetings: any[];
  crmContacts: any[];
  teamMembers: any[];
}

export async function answerUserQuestion(
  question: string,
  context: CopilotContext
): Promise<{
  answer: string;
  suggestedActions: Array<{
    type: "create_task" | "schedule_meeting" | "send_email" | "update_crm";
    description: string;
    data: any;
  }>;
  relatedData: {
    tasks?: any[];
    emails?: any[];
    contacts?: any[];
    meetings?: any[];
  };
}> {
  try {
    // Build comprehensive context for the AI
    const contextData = {
      recentTasks: context.recentTasks.slice(0, 10),
      recentEmails: context.recentEmails.slice(0, 5),
      recentMeetings: context.recentMeetings.slice(0, 5),
      crmContacts: context.crmContacts.slice(0, 20),
      teamMembers: context.teamMembers,
    };

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are TaskSync AI Copilot, an intelligent assistant with access to the user's work data including:
          - Tasks and projects
          - Email conversations and history
          - Meeting notes and recordings
          - CRM contacts and interactions
          - Team member information
          
          Your role is to:
          1. Answer questions about work data and productivity
          2. Suggest actionable next steps
          3. Identify relevant information from the user's data
          4. Provide insights and recommendations
          
          Always be helpful, accurate, and actionable. Reference specific data when possible.
          
          Respond with JSON in this format:
          {
            "answer": "Direct answer to the user's question",
            "suggestedActions": [
              {
                "type": "create_task|schedule_meeting|send_email|update_crm",
                "description": "What this action does",
                "data": "relevant data for the action"
              }
            ],
            "relatedData": {
              "tasks": "relevant tasks array or null",
              "emails": "relevant emails array or null", 
              "contacts": "relevant contacts array or null",
              "meetings": "relevant meetings array or null"
            }
          }`
        },
        {
          role: "user",
          content: `
          User Question: ${question}
          
          Available Context:
          Recent Tasks: ${JSON.stringify(contextData.recentTasks)}
          Recent Emails: ${JSON.stringify(contextData.recentEmails)}
          Recent Meetings: ${JSON.stringify(contextData.recentMeetings)}
          CRM Contacts: ${JSON.stringify(contextData.crmContacts)}
          Team Members: ${JSON.stringify(contextData.teamMembers)}
          
          Please provide a comprehensive answer and relevant suggestions.`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("Error in AI Copilot:", error);
    throw new Error("Failed to process your question");
  }
}

export async function generateWorkInsights(context: CopilotContext): Promise<{
  insights: Array<{
    type: "productivity" | "collaboration" | "follow_up" | "optimization";
    title: string;
    description: string;
    priority: "low" | "medium" | "high";
    actionable: boolean;
  }>;
  summary: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Analyze the user's work data and generate actionable insights about:
          - Productivity patterns
          - Collaboration opportunities  
          - Follow-up requirements
          - Process optimizations
          
          Focus on specific, actionable recommendations based on the actual data.
          
          Respond with JSON:
          {
            "insights": [
              {
                "type": "productivity|collaboration|follow_up|optimization",
                "title": "Brief insight title",
                "description": "Detailed description with specific recommendations",
                "priority": "low|medium|high",
                "actionable": boolean
              }
            ],
            "summary": "Overall summary of work patterns and recommendations"
          }`
        },
        {
          role: "user",
          content: `
          Analyze this work data for insights:
          
          Tasks: ${JSON.stringify(context.recentTasks)}
          Emails: ${JSON.stringify(context.recentEmails)}
          Meetings: ${JSON.stringify(context.recentMeetings)}
          CRM Data: ${JSON.stringify(context.crmContacts)}
          Team: ${JSON.stringify(context.teamMembers)}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("Error generating insights:", error);
    throw new Error("Failed to generate work insights");
  }
}

export async function suggestMeetingAgenda(
  meetingTitle: string,
  participants: string[],
  context: CopilotContext
): Promise<{
  agenda: Array<{
    topic: string;
    duration: string;
    description: string;
    presenter?: string;
  }>;
  preparationItems: string[];
  followUpActions: string[];
}> {
  try {
    // Find relevant context for participants
    const participantContext = context.crmContacts.filter(contact => 
      participants.some(p => p.toLowerCase().includes(contact.email?.toLowerCase() || ''))
    );

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Create a comprehensive meeting agenda based on the meeting title, participants, and relevant work context.
          
          Consider:
          - Recent interactions with participants
          - Relevant ongoing tasks and projects
          - CRM history and relationship context
          - Team dynamics and roles
          
          Respond with JSON:
          {
            "agenda": [
              {
                "topic": "agenda item",
                "duration": "estimated time",
                "description": "detailed description",
                "presenter": "who should present or null"
              }
            ],
            "preparationItems": ["item1", "item2"],
            "followUpActions": ["action1", "action2"]
          }`
        },
        {
          role: "user",
          content: `
          Meeting: ${meetingTitle}
          Participants: ${participants.join(', ')}
          
          Context about participants: ${JSON.stringify(participantContext)}
          Recent tasks: ${JSON.stringify(context.recentTasks.slice(0, 5))}
          Recent meetings: ${JSON.stringify(context.recentMeetings.slice(0, 3))}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("Error suggesting meeting agenda:", error);
    throw new Error("Failed to suggest meeting agenda");
  }
}