import OpenAI from "openai";
import { storage } from "../storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_SECRET_KEY || process.env.OPENAI_TOKEN
});

export interface EmailMonitoringResult {
  shouldCreateTask: boolean;
  suggestedTask?: {
    title: string;
    description: string;
    priority: "low" | "medium" | "high";
    dueDate?: string;
  };
  shouldUpdateCrm: boolean;
  crmUpdate?: {
    contactId?: number;
    notes: string;
    interactionType: "email" | "follow_up" | "meeting_request";
  };
  contextAnalysis: {
    sentiment: "positive" | "neutral" | "negative";
    urgency: "low" | "medium" | "high";
    topics: string[];
    actionItems: string[];
  };
}

export async function analyzeEmailContent(
  content: string,
  sender: string,
  conversationHistory: string[],
  crmContext?: any
): Promise<EmailMonitoringResult> {
  try {
    const context = `
Email from: ${sender}
Recent conversation history: ${conversationHistory.slice(-3).join('\n')}
CRM Context: ${crmContext ? JSON.stringify(crmContext) : 'No CRM data available'}

Email content:
${content}
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an AI email monitoring assistant for TaskSync. Analyze incoming emails and determine:
          
          1. Whether this email requires creating a task
          2. If CRM data should be updated
          3. Context analysis (sentiment, urgency, topics, action items)
          
          Consider:
          - Past conversation context with this contact
          - Urgency indicators in the email
          - Action items or requests mentioned
          - Meeting requests or deadlines
          - Follow-up requirements
          
          Respond with JSON in this exact format:
          {
            "shouldCreateTask": boolean,
            "suggestedTask": {
              "title": "string",
              "description": "string", 
              "priority": "low|medium|high",
              "dueDate": "YYYY-MM-DD or null"
            },
            "shouldUpdateCrm": boolean,
            "crmUpdate": {
              "notes": "string",
              "interactionType": "email|follow_up|meeting_request"
            },
            "contextAnalysis": {
              "sentiment": "positive|neutral|negative",
              "urgency": "low|medium|high", 
              "topics": ["topic1", "topic2"],
              "actionItems": ["action1", "action2"]
            }
          }`
        },
        {
          role: "user",
          content: context,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result as EmailMonitoringResult;
  } catch (error) {
    console.error("Error analyzing email content:", error);
    throw new Error("Failed to analyze email content");
  }
}

export async function generateEmailResponse(
  emailContent: string,
  conversationHistory: string[],
  userContext: any
): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an AI assistant helping to draft professional email responses. 
          Consider the conversation history and user's business context to suggest an appropriate response.
          Keep responses professional, concise, and actionable.`
        },
        {
          role: "user",
          content: `
          Original email: ${emailContent}
          
          Conversation history: ${conversationHistory.join('\n')}
          
          User context: ${JSON.stringify(userContext)}
          
          Please suggest a professional email response.`,
        },
      ],
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Error generating email response:", error);
    throw new Error("Failed to generate email response");
  }
}

export async function extractMeetingInfo(emailContent: string): Promise<{
  hasMeetingRequest: boolean;
  meetingDetails?: {
    title: string;
    proposedTimes: string[];
    duration?: string;
    location?: string;
    attendees: string[];
  };
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Analyze the email content for meeting requests or scheduling information.
          
          Respond with JSON:
          {
            "hasMeetingRequest": boolean,
            "meetingDetails": {
              "title": "string",
              "proposedTimes": ["time1", "time2"],
              "duration": "string or null",
              "location": "string or null", 
              "attendees": ["email1", "email2"]
            }
          }`
        },
        {
          role: "user",
          content: emailContent,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("Error extracting meeting info:", error);
    return { hasMeetingRequest: false };
  }
}