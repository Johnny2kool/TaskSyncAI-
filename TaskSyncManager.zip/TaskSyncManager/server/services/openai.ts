import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_SECRET_KEY || process.env.OPENAI_TOKEN
});

export interface GeneratedTask {
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  dueDate?: string;
}

export async function generateTasksFromText(text: string): Promise<GeneratedTask[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a task management assistant. Analyze the provided text and extract actionable tasks. 
          For each task, provide:
          - title: A clear, concise task title (max 60 characters)
          - description: A detailed description of what needs to be done
          - priority: "low", "medium", or "high" based on urgency and importance
          - dueDate: Optional ISO date string if a deadline is mentioned
          
          Respond with a JSON array of tasks. Example:
          [{"title": "Review document", "description": "Review the quarterly report and provide feedback", "priority": "high", "dueDate": "2024-01-15"}]`
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.tasks || [];
  } catch (error) {
    console.error("Error generating tasks:", error);
    throw new Error("Failed to generate tasks from text");
  }
}

export async function summarizeMeetingNotes(content: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a meeting assistant. Summarize the meeting notes into key points, decisions made, and action items. Keep it concise and well-structured."
        },
        {
          role: "user",
          content: `Please summarize these meeting notes:\n\n${content}`,
        },
      ],
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("Error summarizing meeting notes:", error);
    throw new Error("Failed to summarize meeting notes");
  }
}

export async function generateTaskSuggestions(userContext: string): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Based on the user's context, suggest 3-5 productivity tasks that would be beneficial. 
          Respond with a JSON object containing an array of task suggestions.
          Example: {"suggestions": ["Review weekly goals", "Plan next sprint", "Update documentation"]}`
        },
        {
          role: "user",
          content: userContext,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.suggestions || [];
  } catch (error) {
    console.error("Error generating task suggestions:", error);
    return [];
  }
}
