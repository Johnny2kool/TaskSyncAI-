import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { generateTasksFromText, summarizeMeetingNotes } from "./services/openai";
import { sendTaskAssignment, sendTaskReminder } from "./services/twilio";
import { insertTaskSchema, insertWorkspaceSchema, insertMeetingNoteSchema } from "@shared/schema";

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Subscription routes
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        res.json({
          subscriptionId: subscription.id,
          clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
        });
        return;
      }
      
      if (!user.email) {
        throw new Error('No user email on file');
      }

      const customer = await stripe.customers.create({
        email: user.email,
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
      });

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price_data: {
            currency: 'usd',
            product_data: {
              name: 'TaskSync Pro',
              description: 'AI-powered task management platform',
            },
            unit_amount: 500, // $5.00
            recurring: {
              interval: 'month',
            },
          },
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      await storage.updateUserStripeInfo(userId, customer.id, subscription.id);

      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(400).json({ message: error.message });
    }
  });

  // Workspace routes
  app.post('/api/workspaces', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workspaceData = insertWorkspaceSchema.parse({
        ...req.body,
        ownerId: userId,
      });
      
      const workspace = await storage.createWorkspace(workspaceData);
      res.json(workspace);
    } catch (error) {
      console.error("Error creating workspace:", error);
      res.status(500).json({ message: "Failed to create workspace" });
    }
  });

  app.get('/api/workspaces', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workspaces = await storage.getUserWorkspaces(userId);
      res.json(workspaces);
    } catch (error) {
      console.error("Error fetching workspaces:", error);
      res.status(500).json({ message: "Failed to fetch workspaces" });
    }
  });

  app.get('/api/workspaces/:id/members', isAuthenticated, async (req, res) => {
    try {
      const workspaceId = parseInt(req.params.id);
      const members = await storage.getWorkspaceMembers(workspaceId);
      res.json(members);
    } catch (error) {
      console.error("Error fetching workspace members:", error);
      res.status(500).json({ message: "Failed to fetch workspace members" });
    }
  });

  app.get('/api/workspaces/:id/stats', isAuthenticated, async (req, res) => {
    try {
      const workspaceId = parseInt(req.params.id);
      const stats = await storage.getTaskStats(workspaceId);
      const members = await storage.getWorkspaceMembers(workspaceId);
      
      res.json({
        ...stats,
        teamMembers: members.length,
      });
    } catch (error) {
      console.error("Error fetching workspace stats:", error);
      res.status(500).json({ message: "Failed to fetch workspace stats" });
    }
  });

  // Task routes
  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const taskData = insertTaskSchema.parse(req.body);
      
      const task = await storage.createTask(taskData);
      
      // Send SMS notification if assignee has phone number
      if (task.assigneeId && task.assigneeId !== userId) {
        const assignee = await storage.getUser(task.assigneeId);
        const assigner = await storage.getUser(userId);
        if (assignee?.phoneNumber && assigner) {
          await sendTaskAssignment(
            assignee.phoneNumber,
            task.title,
            `${assigner.firstName} ${assigner.lastName}`.trim() || assigner.email || 'Someone'
          );
        }
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workspaceId = req.query.workspaceId ? parseInt(req.query.workspaceId as string) : undefined;
      const tasks = await storage.getUserTasks(userId, workspaceId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.patch('/api/tasks/:id/status', isAuthenticated, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const { status } = req.body;
      
      const task = await storage.updateTaskStatus(taskId, status);
      res.json(task);
    } catch (error) {
      console.error("Error updating task status:", error);
      res.status(500).json({ message: "Failed to update task status" });
    }
  });

  // AI-powered task generation
  app.post('/api/ai/generate-tasks', isAuthenticated, async (req, res) => {
    try {
      const { text, workspaceId } = req.body;
      
      if (!text || !workspaceId) {
        return res.status(400).json({ message: "Text and workspaceId are required" });
      }
      
      const generatedTasks = await generateTasksFromText(text);
      res.json({ tasks: generatedTasks });
    } catch (error) {
      console.error("Error generating tasks:", error);
      res.status(500).json({ message: "Failed to generate tasks" });
    }
  });

  // Meeting notes routes
  app.post('/api/meeting-notes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const noteData = insertMeetingNoteSchema.parse({
        ...req.body,
        createdById: userId,
      });
      
      // Generate AI summary if content is provided
      if (noteData.content) {
        try {
          noteData.summary = await summarizeMeetingNotes(noteData.content);
        } catch (error) {
          console.warn("Failed to generate AI summary:", error);
        }
      }
      
      const note = await storage.createMeetingNote(noteData);
      res.json(note);
    } catch (error) {
      console.error("Error creating meeting note:", error);
      res.status(500).json({ message: "Failed to create meeting note" });
    }
  });

  app.get('/api/meeting-notes', isAuthenticated, async (req, res) => {
    try {
      const workspaceId = parseInt(req.query.workspaceId as string);
      if (!workspaceId) {
        return res.status(400).json({ message: "workspaceId is required" });
      }
      
      const notes = await storage.getMeetingNotes(workspaceId);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching meeting notes:", error);
      res.status(500).json({ message: "Failed to fetch meeting notes" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch('/api/notifications/:id/read', isAuthenticated, async (req, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      await storage.markNotificationRead(notificationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Sample data route for testing
  app.post("/api/seed-data", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { seedTestData } = await import("./seedData");
      const result = await seedTestData(userId);
      res.json({ 
        message: "Sample data created successfully", 
        data: {
          contactsCreated: result.contacts.length,
          tasksCreated: result.tasks.length,
          conversationCreated: !!result.conversation
        }
      });
    } catch (error: any) {
      console.error("Error seeding data:", error);
      res.status(500).json({ message: "Failed to create sample data: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
