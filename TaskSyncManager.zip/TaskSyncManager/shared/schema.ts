import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  boolean,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  stripeCustomerId: varchar("stripe_customer_id"),
  stripeSubscriptionId: varchar("stripe_subscription_id"),
  phoneNumber: varchar("phone_number"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const workspaces = pgTable("workspaces", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  description: text("description"),
  priority: varchar("priority").notNull().default("medium"), // low, medium, high
  status: varchar("status").notNull().default("pending"), // pending, in_progress, completed
  assigneeId: varchar("assignee_id").references(() => users.id),
  workspaceId: integer("workspace_id").references(() => workspaces.id).notNull(),
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const workspaceMembers = pgTable("workspace_members", {
  id: serial("id").primaryKey(),
  workspaceId: integer("workspace_id").references(() => workspaces.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  role: varchar("role").notNull().default("member"), // owner, admin, member
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const meetingNotes = pgTable("meeting_notes", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  content: text("content"),
  summary: text("summary"),
  workspaceId: integer("workspace_id").references(() => workspaces.id).notNull(),
  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: varchar("type").notNull(), // task_assigned, task_completed, meeting_reminder
  title: varchar("title").notNull(),
  message: text("message"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Email accounts and monitoring
export const emailAccounts = pgTable("email_accounts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  email: varchar("email").notNull(),
  provider: varchar("provider").notNull(), // gmail, outlook, etc
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  isActive: boolean("is_active").default(true),
  lastSyncAt: timestamp("last_sync_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailConversations = pgTable("email_conversations", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => emailAccounts.id).notNull(),
  threadId: varchar("thread_id").notNull(),
  participants: text("participants").array().notNull(),
  subject: varchar("subject"),
  lastMessageAt: timestamp("last_message_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailMessages = pgTable("email_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => emailConversations.id).notNull(),
  messageId: varchar("message_id").notNull(),
  sender: varchar("sender").notNull(),
  recipients: text("recipients").array().notNull(),
  subject: varchar("subject"),
  content: text("content"),
  isInbound: boolean("is_inbound").notNull(),
  sentAt: timestamp("sent_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// CRM integration
export const crmContacts = pgTable("crm_contacts", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  email: varchar("email").notNull(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  company: varchar("company"),
  title: varchar("title"),
  phone: varchar("phone"),
  notes: text("notes"),
  lastContactAt: timestamp("last_contact_at"),
  source: varchar("source").default("manual"), // manual, email, meeting
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const crmInteractions = pgTable("crm_interactions", {
  id: serial("id").primaryKey(),
  contactId: integer("contact_id").references(() => crmContacts.id).notNull(),
  type: varchar("type").notNull(), // email, meeting, call, note
  subject: varchar("subject"),
  content: text("content"),
  direction: varchar("direction"), // inbound, outbound
  interactionAt: timestamp("interaction_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// AI conversation context
export const aiConversations = pgTable("ai_conversations", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: varchar("title"),
  context: jsonb("context"), // Stores conversation history and context
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const aiMessages = pgTable("ai_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => aiConversations.id).notNull(),
  role: varchar("role").notNull(), // user, assistant
  content: text("content").notNull(),
  metadata: jsonb("metadata"), // Store additional context like referenced emails, tasks, etc
  createdAt: timestamp("created_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertWorkspace = typeof workspaces.$inferInsert;
export type Workspace = typeof workspaces.$inferSelect;

export type InsertTask = typeof tasks.$inferInsert;
export type Task = typeof tasks.$inferSelect;

export type InsertWorkspaceMember = typeof workspaceMembers.$inferInsert;
export type WorkspaceMember = typeof workspaceMembers.$inferSelect;

export type InsertMeetingNote = typeof meetingNotes.$inferInsert;
export type MeetingNote = typeof meetingNotes.$inferSelect;

export type InsertNotification = typeof notifications.$inferInsert;
export type Notification = typeof notifications.$inferSelect;

export type InsertEmailAccount = typeof emailAccounts.$inferInsert;
export type EmailAccount = typeof emailAccounts.$inferSelect;

export type InsertEmailConversation = typeof emailConversations.$inferInsert;
export type EmailConversation = typeof emailConversations.$inferSelect;

export type InsertEmailMessage = typeof emailMessages.$inferInsert;
export type EmailMessage = typeof emailMessages.$inferSelect;

export type InsertCrmContact = typeof crmContacts.$inferInsert;
export type CrmContact = typeof crmContacts.$inferSelect;

export type InsertCrmInteraction = typeof crmInteractions.$inferInsert;
export type CrmInteraction = typeof crmInteractions.$inferSelect;

export type InsertAiConversation = typeof aiConversations.$inferInsert;
export type AiConversation = typeof aiConversations.$inferSelect;

export type InsertAiMessage = typeof aiMessages.$inferInsert;
export type AiMessage = typeof aiMessages.$inferSelect;

export const insertWorkspaceSchema = createInsertSchema(workspaces).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true,
});

export const insertMeetingNoteSchema = createInsertSchema(meetingNotes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmailAccountSchema = createInsertSchema(emailAccounts).omit({
  id: true,
  createdAt: true,
  lastSyncAt: true,
});

export const insertCrmContactSchema = createInsertSchema(crmContacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAiConversationSchema = createInsertSchema(aiConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
